# Project 06 – Azure Portal Walkthrough: Standard Load Balancer with Two VMs

Build the whole project by hand in the Azure Portal. Portal labels change from time to time; if a name doesn't match exactly, pick the closest option.

| | |
|---|---|
| **Time** | About 3 hours (Part A–B: 30 min free; Parts C–H: about 2–2.5 hours charged) |
| **Region** | **(US) East US 2** for every resource |
| **Cost** | Free until Part C. From Part C: **about $0.23 per hour** (2 × D2s_v3 ≈ $0.20, load balancer ≈ $0.025, public IP ≈ $0.005) |
| **You need** | `scripts/cloud-init-web.yaml` from this folder |

## 💰 Where charging starts – read this first

| Part | What | Cost |
|---|---|---|
| **A** | Resource group, NSG and its rules | ✅ **Free** |
| **B** | VNet and subnets | ✅ **Free** |
| 🛑 | **FREE STOPPING POINT** – everything above can stay in place for days at no cost | |
| **C** | **Public IP + Standard Load Balancer** | 💰 **Charging starts** – the public IP bills from creation; the load balancer bills once it has rules |
| **D** | **Two VMs** | 💰 ~$0.10 per hour each while running |
| **E–G** | Tests and optional NAT rule demo | 💰 (uses the resources above) |
| **H** | **Delete the resource group** | ✅ Charging stops |

**Plan:** do Parts A–B whenever you like. Do **Parts C to H in one sitting** (about 2–2.5 hours) and finish with the cleanup.

### What you'll build

```
rg-az104-project06 (East US 2)
│
├── nsg-web                               ← floor guard on snet-web
├── pip-lb-az104-project06 (zone-redundant) ← the building's front door
├── lb-az104-project06 (Standard, public) ← the receptionist
│     ├── frontend  fe-web  → pip-lb-az104-project06
│     ├── backend pool  bepool-web  → vm-lb1, vm-lb2
│     ├── health probe  probe-http  (HTTP :80 /)
│     ├── LB rule  rule-http  (TCP 80 → 80)
│     ├── outbound rule  rule-outbound  (lets the VMs download Nginx)
│     └── (optional) inbound NAT rule  nat-ssh-vm-lb1  (50001 → vm-lb1:22)
│
└── vnet-az104-project06 (10.10.0.0/16)
    ├── snet-web 10.10.1.0/24  (private, nsg-web)
    │     ├── vm-lb1  Zone 1  no public IP  Nginx
    │     └── vm-lb2  Zone 2  no public IP  Nginx
    └── AzureBastionSubnet 10.10.254.0/26 (reserved for Project 07)
```

---

# Part A – Resource group and NSG (≈ 20 min, FREE)

## Step 0: Sign in and check capacity

1. Go to **portal.azure.com**, sign in, and check the directory under your name is **Default Directory**.
2. **Check D2s_v3 is available in zones 1 and 2** (2 minutes – avoids building everything and then failing at the VMs). In your terminal:
   ```bash
   az vm list-skus --location eastus2 --size Standard_D2s_v3 \
     --query "[0].{Zones:locationInfo[0].zones, Restricted:restrictions[].restrictionInfo.zones}" -o json
   ```
   Use two zones that appear under **Zones** but **not** under **Restricted**. The walkthrough uses **1 and 2**; swap in others if needed.
3. **Check your quota:** `az vm list-usage --location eastus2 -o table | grep -i "DSv3\|Total Regional"`. Two D2s_v3 need **4 free vCPUs** in the DSv3 family. Make sure no Project 05 VMs are still running.

## Step 1: Resource group

1. Search **Resource groups** → **+ Create**.
2. **Basics:** Subscription = portfolio projects, Name = `rg-az104-project06`, Region = **(US) East US 2**.
3. **Tags:** `Environment = Lab`, `CostCenter = IT-Services`, `Owner = Harold Nduna`, `Project = AZ104-Project06`.
4. **Review + create** → **Create**.

Use these four tags on **every** resource below.

## Step 2: NSG – deliberately WITHOUT a web rule (yet)

1. Search **Network security groups** → **+ Create** → RG `rg-az104-project06`, Name **`nsg-web`**, Region **East US 2**, tags → **Create**.
2. Open `nsg-web` → **Settings → Inbound security rules → + Add**. Add only these two (Source port ranges always `*`):

| Priority | Name | Source | Source value | Destination | Dest. value | Service / port | Protocol | Action |
|---|---|---|---|---|---|---|---|---|
| 110 | Allow-Mgmt-Bastion | IP Addresses | 10.10.254.0/26 | IP Addresses | 10.10.1.0/24 | Custom, `22,3389` | TCP | Allow |
| 4000 | Deny-VNet-Inbound | Service Tag | VirtualNetwork | Any | – | Custom, `*` | Any | **Deny** |

> **Why no port 80 rule?** Test 1 proves that a **Standard Load Balancer is secure by default**: the website won't load until you add the HTTP rule in Part E.

> **Health probes are already allowed:** the default rule **AllowAzureLoadBalancerInBound (65001)** lets probes from `168.63.129.16` through. Our Deny-VNet-Inbound rule doesn't block them, because the `AzureLoadBalancer` tag is separate from `VirtualNetwork`.

---

# Part B – Network (≈ 10 min, FREE)

## Step 3: Virtual network

1. Search **Virtual networks** → **+ Create**.
2. **Basics:** RG `rg-az104-project06`, Name `vnet-az104-project06`, Region **East US 2**.
3. **Security:** leave Bastion, Firewall and DDoS **off**.
4. **IP addresses:** delete the `default` subnet, set the address space to **10.10.0.0/16**, then **+ Add a subnet**:

| Name | Starting address | Size | Private subnet | NSG |
|---|---|---|---|---|
| `snet-web` | 10.10.1.0 | /24 | ✅ | **nsg-web** |
| `AzureBastionSubnet` (purpose: Azure Bastion) | 10.10.254.0 | /26 | – | None |

5. **Tags** → **Review + create** → **Create**.

> The subnet is **private** – no default internet access. The VMs will get outbound internet through the load balancer's **outbound rule** (Step 4).

---

# 🛑 FREE STOPPING POINT

Everything so far is **free** and can be left in place. **Only continue when you have about 2–2.5 hours to finish Parts C–H in one go.**

---

# Part C – Load balancer (≈ 25 min) 💰 CHARGING STARTS

## Step 4: Create the Standard Load Balancer

Search **Load balancers** → **+ Create**.

### Basics

| Field | Value |
|---|---|
| Resource group | `rg-az104-project06` |
| Name | `lb-az104-project06` |
| Region | **East US 2** |
| SKU | **Standard** (Basic is retired) |
| Type | **Public** |
| Tier | **Regional** |

### Frontend IP configuration → + Add a frontend IP configuration

| Field | Value |
|---|---|
| Name | `fe-web` |
| IP version | IPv4 |
| IP type | IP address |
| Public IP address | **Create new** → Name `pip-lb-az104-project06`, Availability zone **Zone-redundant** → **Save** |

Click **Save** / **Add**. The zone-redundant public IP means the front door survives a whole datacenter failing.

### Backend pools → + Add a backend pool

| Field | Value |
|---|---|
| Name | `bepool-web` |
| Virtual network | `vnet-az104-project06` |
| Backend pool configuration | **NIC** |
| IP configurations | Leave empty – the VMs join it when they're created (Step 6) |

Click **Save**.

### Inbound rules → + Add a load balancing rule

| Field | Value |
|---|---|
| Name | `rule-http` |
| IP version | IPv4 |
| Frontend IP address | `fe-web` |
| Backend pool | `bepool-web` |
| Protocol | **TCP** |
| Port | **80** |
| Backend port | **80** |
| Health probe | **Create new** → Name `probe-http`, Protocol **HTTP**, Port **80**, Path **/**, Interval **5** seconds → **Save** |
| Session persistence | **None** |
| Idle timeout (minutes) | 4 |
| Enable TCP Reset | ✅ |
| Enable Floating IP | ❌ |
| Outbound source network address translation (SNAT) | **(Recommended) Use outbound rules to provide backend pool members access to the internet** |

Click **Save**. Skip **Inbound NAT rules** for now (optional demo in Part G).

### Outbound rules → + Add an outbound rule

| Field | Value |
|---|---|
| Name | `rule-outbound` |
| IP version | IPv4 |
| Frontend IP address | `fe-web` |
| Protocol | **All** |
| Idle timeout (minutes) | 4 |
| TCP Reset | Enabled |
| Backend pool | `bepool-web` |
| Port allocation | **Manually choose number of outbound ports** |
| Choose by | **Maximum number of backend instances** → **2** |

Click **Save** / **Add**.

> **Outbound rule vs NAT Gateway:** Project 05 used a NAT Gateway for outbound internet; this project uses a **load balancer outbound rule**. Both are "explicit outbound" methods. If a subnet had both, the **NAT Gateway would take precedence**.

### Tags → Review + create → Create

When it's deployed, open **pip-lb-az104-project06** and **note its IP address** – this is your website's address.

---

# Part D – Virtual machines (≈ 30 min) 💰

## Step 5: Copy the cloud-init file

Open `scripts/cloud-init-web.yaml` in VS Code → **Ctrl + A** → **Ctrl + C**. The first line must be `#cloud-config`.

It installs Nginx at first boot and publishes a page showing **which server** and **which zone** answered.

## Step 6: vm-lb1 (Zone 1)

Search **Virtual machines** → **+ Create → Azure virtual machine**.

### Basics

| Field | Value |
|---|---|
| Resource group | `rg-az104-project06` |
| Virtual machine name | **`vm-lb1`** |
| Region | **(US) East US 2** |
| Availability options | **Availability zone** |
| Availability zone | **Zone 1 only** (untick any others) |
| Security type | Trusted launch virtual machines |
| Image | **Ubuntu Server 24.04 LTS – x64 Gen2** |
| Size | **Standard_D2s_v3** – select it from *See all sizes* and **don't change the vCPU options** |
| Authentication type | SSH public key |
| Username | `azureuser` |
| SSH public key source | **Generate new key pair**, name `az104-p06-key` |
| Public inbound ports | **None** |

### Disks

| Field | Value |
|---|---|
| OS disk type | **Standard HDD (locally-redundant storage)** |
| Delete with VM | ✅ |
| Key management | Platform-managed key |
| Data disks | None |

### Networking

| Field | Value |
|---|---|
| Virtual network | `vnet-az104-project06` |
| Subnet | **snet-web (10.10.1.0/24)** |
| Public IP | **None** |
| NIC network security group | **None** (the subnet NSG protects it) |
| Delete NIC when VM is deleted | ✅ |
| **Load balancing options** | **Azure load balancer** |
| Select a load balancer | **`lb-az104-project06`** |
| Select a backend pool | **`bepool-web`** |

> Joining the backend pool **at creation** matters: the outbound rule only gives internet access to pool members, and cloud-init needs it at first boot to download Nginx.

### Management

| Field | Value |
|---|---|
| Enable auto-shutdown | ✅ |
| Shutdown time | 7:00:00 PM |
| Time zone | (UTC+01:00) / Central European |
| Notification | Off |

### Monitoring

Boot diagnostics: **Enable with managed storage account (recommended)**.

### Advanced

**Custom data:** paste the whole `cloud-init-web.yaml`. Check it starts with `#cloud-config`.

### Tags → Review + create → Create

**Download private key and create resource.** Save `az104-p06-key.pem` in your **Downloads** folder (not in the repo) – the optional NAT rule demo uses it.

## Step 7: vm-lb2 (Zone 2)

Exactly the same as Step 6, **except**:

| Field | Value |
|---|---|
| Virtual machine name | **`vm-lb2`** |
| Availability zone | **Zone 2 only** |
| SSH public key source | **Use existing key stored in Azure** → `az104-p06-key` |

Everything else – size, image, subnet, **no public IP**, **load balancer `lb-az104-project06` / backend pool `bepool-web`**, auto-shutdown, boot diagnostics, **custom data**, tags – is the same.

### If a VM fails with `SkuNotAvailable` / "not available in zone"

That zone has no capacity. Recreate the VM in the remaining zone (e.g. **Zone 3**). If no zone works, choose **Availability set** instead (create a new set `avset-web`) and put both VMs in it – note it in your README.

## Step 8: Check the VMs and the pool

1. **Load balancers** → `lb-az104-project06` → **Settings → Backend pools** → `bepool-web` shows **vm-lb1** and **vm-lb2**.
2. Open each VM's **Overview**: note the **private IP** (likely 10.10.1.4 and 10.10.1.5) and **Availability zone** (1 and 2).
3. **Wait 3–5 minutes** for cloud-init, then check Nginx on each VM: VM → **Operations → Run command → RunShellScript**:
   ```bash
   cloud-init status; systemctl is-active nginx; curl -s http://localhost | grep "Served by"
   ```
   **Expected:** `status: done`, `active`, and `Served by: vm-lb1` (or vm-lb2).

   If Nginx isn't installed, run this to install it (uses the outbound rule):
   ```bash
   apt-get update -q && apt-get install -y -q nginx && echo "<h1>Served by: $(hostname)</h1>" > /var/www/html/index.html && systemctl enable --now nginx && echo OK
   ```

---

# Part E – Core tests (≈ 30 min) 💰

Use `<LB-IP>` = the public IP of `pip-lb-az104-project06`.

## Test 1: Secure by default (website BLOCKED)

1. In your browser, open **`http://<LB-IP>`** (http, not https).
2. **Expected:** the page **doesn't load** (spins, then times out).

Why: the Standard Load Balancer forwards the traffic, but `nsg-web` has **no rule allowing port 80 from the Internet**, so the default **DenyAllInBound** drops it.

📸 Screenshot the browser timing out, with the address bar visible.

## Test 2: Allow HTTP – website WORKS

1. `nsg-web` → **Inbound security rules → + Add**:

| Priority | Name | Source | Source value | Destination | Dest. value | Port | Protocol | Action |
|---|---|---|---|---|---|---|---|---|
| 100 | Allow-HTTP-Internet | Service Tag | Internet | IP Addresses | 10.10.1.0/24 | 80 | TCP | Allow |

2. Wait 30 seconds and refresh **`http://<LB-IP>`**.
3. **Expected:** the page shows **"Served by: vm-lb1"** (or vm-lb2) and its **availability zone**.

📸 Screenshot the page.

> The NSG rule's **destination is the VM subnet**, not the load balancer's IP – the load balancer passes traffic through to the VMs, and the NSG on the VMs' subnet makes the decision. The **source** stays the visitor's real IP, which is why `Internet` matches.

## Test 3: Distribution across both servers

Browsers reuse connections, so use your **Ubuntu terminal** (replace `<LB-IP>`):

```bash
for i in $(seq 1 10); do curl -s http://<LB-IP> | grep -o "vm-lb[12]"; done
```

`for i in $(seq 1 10)` repeats 10 times; `curl -s` fetches the page; `grep -o "vm-lb[12]"` shows only the server name.

**Expected:** a mix of **vm-lb1** and **vm-lb2**. Each `curl` is a new connection with a new source port, so the **5-tuple hash** spreads them.

📸 Screenshot the terminal output.

## Test 4: Health check and failover

1. Open **vm-lb1** → **Run command → RunShellScript**:
   ```bash
   systemctl stop nginx && echo "nginx stopped on $(hostname)"
   ```
2. Wait **about 30 seconds** (the probe checks every 5 seconds).
3. Run the curl loop again from Test 3.
4. **Expected:** **only vm-lb2** answers. The website stayed up even though a server failed.
5. See the probe's view: `lb-az104-project06` → **Monitoring → Metrics** → Metric **Health Probe Status** → **Apply splitting** by **Backend IP Address**. vm-lb1's line drops to 0 (unhealthy); vm-lb2 stays at 100.

📸 Screenshot the curl output (only vm-lb2) and the Health Probe Status chart.

## Test 5: Recovery

1. On **vm-lb1** → Run command:
   ```bash
   systemctl start nginx && echo "nginx started on $(hostname)"
   ```
2. Wait 30 seconds, run the curl loop again.
3. **Expected:** both servers answer again – vm-lb1 rejoined automatically.

---

# Part F – Session persistence (≈ 10 min) 💰

## Test 6: Client IP persistence

1. `lb-az104-project06` → **Settings → Load balancing rules** → `rule-http`.
2. **Session persistence** → **Client IP** → **Save**. Wait about a minute.
3. Run the curl loop.
4. **Expected:** **all 10 answers come from the same server** – the load balancer now hashes on your IP only.
5. **Set it back to None** and save.

📸 Screenshot the curl output.

| Session persistence | Hash | Same visitor → same server? |
|---|---|---|
| **None** (default) | 5-tuple (src IP, src port, dst IP, dst port, protocol) | Not guaranteed |
| **Client IP** | 2-tuple (src IP, dst IP) | Yes |
| **Client IP and protocol** | 3-tuple (+ protocol) | Yes, per protocol |

---

# Part G – OPTIONAL: Inbound NAT rule, done safely (≈ 15 min) 💰

This opens SSH to **one VM, from your IP only, temporarily**.

## Step 9: Create the NAT rule

1. `lb-az104-project06` → **Settings → Inbound NAT rules → + Add**:

| Field | Value |
|---|---|
| Name | `nat-ssh-vm-lb1` |
| Type | **Azure virtual machine** |
| Target virtual machine | **vm-lb1** |
| Network IP configuration | ipconfig1 |
| Frontend IP address | `fe-web` |
| Frontend port | **50001** |
| Service tag | Custom |
| Backend port | **22** |
| Protocol | TCP |
| Enable TCP Reset | ✅ |
| Idle timeout | 4 |

2. **Add**.

## Step 10: Allow SSH from YOUR IP only

`nsg-web` → **Inbound security rules → + Add**:

| Priority | Name | Source | Destination | Port | Protocol | Action |
|---|---|---|---|---|---|---|
| 120 | Allow-SSH-MyIP-TEMP | **My IP address** | IP Addresses → 10.10.1.0/24 | 22 | TCP | Allow |

> The NSG checks the **backend** port (22), not the frontend port (50001) – the load balancer translates the port before the traffic reaches the subnet.

## Step 11: Connect

In your Ubuntu terminal:

```bash
chmod 400 ~/Downloads/az104-p06-key.pem
ssh -i ~/Downloads/az104-p06-key.pem -p 50001 azureuser@<LB-IP>
```

- `chmod 400` makes the key readable only by you (SSH refuses keys that others can read).
- `-p 50001` connects to the load balancer's port 50001, which forwards to **vm-lb1:22**.

Type `yes` to the fingerprint question. You're now on vm-lb1. Run `hostname` (shows `vm-lb1`), then `exit`.

📸 Screenshot the SSH session showing `hostname`.

## Step 12: Remove it straight away

1. `lb-az104-project06` → **Inbound NAT rules** → delete **nat-ssh-vm-lb1**.
2. `nsg-web` → **Inbound security rules** → delete **Allow-SSH-MyIP-TEMP**.

> **Security+ point:** least privilege (one VM, one port, one source IP), minimal exposure time, and removal afterwards. In production, **Azure Bastion** (Project 07) avoids opening management ports at all.

---

# Part H – Clean up (≈ 10 min) – 💰 charging stops

1. **Resource groups** → `rg-az104-project06` → check the list (2 VMs, disks, NICs, NSG, VNet, load balancer, public IP).
2. **Delete resource group** → tick **Apply force delete for selected Virtual machines** → type `rg-az104-project06` → **Delete**.
3. Watch the **bell icon** (5–10 minutes).
4. Confirm in the terminal:
   ```bash
   az group exists --name rg-az104-project06   # expect: false
   ```
5. Delete `~/Downloads/az104-p06-key.pem` – its VMs are gone.

📸 Screenshot the `false`.

---

# Screenshot checklist (`screenshots/gui/`)

| # | File name | Where |
|---|---|---|
| 00 | `00 Resource Group Created.png` | rg-az104-project06 with tags |
| 01 | `01 NSG Web Inbound Rules (No HTTP).png` | nsg-web before the HTTP rule |
| 02 | `02 VNet + Subnets.png` | VNet → Subnets, snet-web with nsg-web |
| 03 | `03 Load Balancer Frontend IP.png` | LB → Frontend IP configuration (zone-redundant public IP) |
| 04 | `04 Backend Pool.png` | LB → Backend pools: vm-lb1 and vm-lb2 |
| 05 | `05 Health Probe.png` | LB → Health probes: probe-http (HTTP 80 /) |
| 06 | `06 Load Balancing Rule.png` | LB → Load balancing rules: rule-http |
| 07 | `07 Outbound Rule.png` | LB → Outbound rules: rule-outbound |
| 08 | `08 VM LB1 Zone 1.png` | vm-lb1 Overview: Zone 1, no public IP |
| 09 | `09 VM LB2 Zone 2.png` | vm-lb2 Overview: Zone 2, no public IP |
| 10 | `10 Nginx Check Run Command.png` | Run command: cloud-init done, nginx active |
| 11 | `11 Secure By Default Blocked.png` | Browser timing out (Test 1) |
| 12 | `12 NSG Allow HTTP Rule.png` | nsg-web with Allow-HTTP-Internet |
| 13 | `13 Website Working.png` | Browser showing "Served by" + zone (Test 2) |
| 14 | `14 Distribution Test.png` | curl loop: both vm-lb1 and vm-lb2 |
| 15 | `15 Failover Test.png` | curl loop: only vm-lb2 after stopping nginx |
| 16 | `16 Health Probe Status.png` | Metrics chart: vm-lb1 unhealthy |
| 17 | `17 Recovery Test.png` | curl loop: both servers again |
| 18 | `18 Session Persistence Client IP.png` | curl loop: one server only |
| 19 | `19 Inbound NAT Rule.png` | (optional) nat-ssh-vm-lb1 |
| 20 | `20 SSH Via NAT Rule.png` | (optional) SSH session showing hostname |
| 21 | `21 Resource Group Clean Up.png` | Deletion / `az group exists` → false |

Blur subscription IDs, tenant IDs and email addresses. Your **public IP address** (used in "My IP address") is also worth blurring.

---

# What the portal taught you

- A **Standard** load balancer is closed until an **NSG** allows the traffic.
- The load balancer is **Layer 4**: it sees IPs and ports, not URLs.
- **Health probes** decide which backends get traffic – and come from `AzureLoadBalancer` (168.63.129.16).
- VMs join a **backend pool** through their **NIC**.
- **Outbound rules** give pool members explicit internet access without public IPs.
- **Inbound NAT rules** map one frontend port to one VM's port – useful, but risky if not restricted.
- **Zones** spread the VMs across datacenters; a **zone-redundant** frontend survives a zone failure.
